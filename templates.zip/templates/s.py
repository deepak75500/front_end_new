import tkinter as tk
from tkinter import ttk, messagebox

# Function to handle form submission
def save_user():
    email = email_entry.get()
    user_id = id_entry.get()
    userid = userid_entry.get()
    password = password_entry.get()
    confirm_password = confirm_password_entry.get()
    user_firm_name = user_firm_name_entry.get()
    user_form_id = user_form_id_entry.get()
    name = name_entry.get()
    user_system_name = user_system_name_entry.get()
    username = username_entry.get()
    role = role_combobox.get()
    theme = theme_combobox.get()

    if password != confirm_password:
        messagebox.showerror("Error", "Passwords do not match!")
        return

    # Print to console for demonstration (replace with actual save logic)
    print(f"Email: {email}, ID: {user_id}, UserID: {userid}, Password: {password}, "
          f"User Firm Name: {user_firm_name}, User Form ID: {user_form_id}, Name: {name}, "
          f"User System Name: {user_system_name}, Username: {username}, Role: {role}, Theme: {theme}")

    # Close the current window
    root.destroy()

    # Open a new window
    open_new_window()

# Function to open a new window
def open_new_window():
    global root
    root = tk.Tk()
    root.title("Update User")

    # Remove default Tkinter icon (set a custom icon if you have one)
    root.iconbitmap('')  # This removes the default icon

    # Set font
    font = ('Arial', 13)

    # Create form labels and entries
    tk.Label(root, text="Email:", font=font).grid(row=0, column=0, padx=5, pady=5, sticky="e")
    global email_entry
    email_entry = tk.Entry(root, font=font)
    email_entry.grid(row=0, column=1, columnspan=3, padx=5, pady=5, sticky="w")

    tk.Label(root, text="ID:", font=font).grid(row=1, column=0, padx=5, pady=5, sticky="e")
    global id_entry
    id_entry = tk.Entry(root, font=font)
    id_entry.grid(row=1, column=1, padx=5, pady=5, sticky="w")

    tk.Label(root, text="User ID:", font=font).grid(row=1, column=2, padx=5, pady=5, sticky="e")
    global userid_entry
    userid_entry = tk.Entry(root, font=font)
    userid_entry.grid(row=1, column=3, padx=5, pady=5, sticky="w")

    tk.Label(root, text="Password:", font=font).grid(row=2, column=0, padx=5, pady=5, sticky="e")
    global password_entry
    password_entry = tk.Entry(root, show="*", font=font)
    password_entry.grid(row=2, column=1, padx=5, pady=5, sticky="w")

    tk.Label(root, text="Confirm Password:", font=font).grid(row=2, column=2, padx=5, pady=5, sticky="e")
    global confirm_password_entry
    confirm_password_entry = tk.Entry(root, show="*", font=font)
    confirm_password_entry.grid(row=2, column=3, padx=5, pady=5, sticky="w")

    tk.Label(root, text="User Firm Name:", font=font).grid(row=3, column=0, padx=5, pady=5, sticky="e")
    global user_firm_name_entry
    user_firm_name_entry = tk.Entry(root, font=font)
    user_firm_name_entry.grid(row=3, column=1, padx=5, pady=5, sticky="w")

    tk.Label(root, text="User Form ID:", font=font).grid(row=3, column=2, padx=5, pady=5, sticky="e")
    global user_form_id_entry
    user_form_id_entry = tk.Entry(root, font=font)
    user_form_id_entry.grid(row=3, column=3, padx=5, pady=5, sticky="w")

    tk.Label(root, text="Name:", font=font).grid(row=4, column=0, padx=5, pady=5, sticky="e")
    global name_entry
    name_entry = tk.Entry(root, font=font)
    name_entry.grid(row=4, column=1, padx=5, pady=5, sticky="w")

    tk.Label(root, text="User System Name:", font=font).grid(row=4, column=2, padx=5, pady=5, sticky="e")
    global user_system_name_entry
    user_system_name_entry = tk.Entry(root, font=font)
    user_system_name_entry.grid(row=4, column=3, padx=5, pady=5, sticky="w")

    tk.Label(root, text="Username:", font=font).grid(row=5, column=0, padx=5, pady=5, sticky="e")
    global username_entry
    username_entry = tk.Entry(root, font=font)
    username_entry.grid(row=5, column=1, padx=5, pady=5, sticky="w")

    tk.Label(root, text="Role:", font=font).grid(row=5, column=2, padx=5, pady=5, sticky="e")
    global role_combobox
    role_combobox = ttk.Combobox(root, values=["admin", "user", "manager"], font=font, height=5)
    role_combobox.grid(row=5, column=3, padx=5, pady=5, sticky="w")

    tk.Label(root, text="Theme:", font=font).grid(row=6, column=0, padx=5, pady=5, sticky="e")
    global theme_combobox
    theme_combobox = ttk.Combobox(root, values=["Yellow", "Red", "LightGreen"], font=font)
    theme_combobox.grid(row=6, column=1, columnspan=3, padx=5, pady=5, sticky="w")
    theme_combobox.current(0)

    # Submit button
    submit_button = tk.Button(root, text="SAVE", command=save_user, font=font)
    submit_button.grid(row=7, column=0, columnspan=4, padx=5, pady=10)

    # Set default values in the form fields
    set_default_values()

    # Center the window
    center_window(root)

    # Run the new window's event loop
    root.mainloop()

# Function to center the window on the screen
def center_window(root):
    root.update_idletasks()
    width = root.winfo_width()
    height = root.winfo_height()
    x = (root.winfo_screenwidth() // 2) - (width // 2)
    y = (root.winfo_screenheight() // 2) - (height // 2)
    root.geometry('{}x{}+{}+{}'.format(width, height, x, y))

# Function to set default values in the form fields
def set_default_values():
    email_entry.insert(0, "user@example.com")
    id_entry.insert(0, "12345")
    userid_entry.insert(0, "userID123")
    password_entry.insert(0, "password123")
    confirm_password_entry.insert(0, "password123")
    user_firm_name_entry.insert(0, "Example Firm")
    user_form_id_entry.insert(0, "UFID123")
    name_entry.insert(0, "John Doe")
    user_system_name_entry.insert(0, "System Name")
    username_entry.insert(0, "johndoe")
    role_combobox.set("admin")
    theme_combobox.set("Yellow")

# Initialize the first window
root = tk.Tk()
root.title("Update User")

# Remove default Tkinter icon (set a custom icon if you have one)
root.iconbitmap('')  # This removes the default icon

# Set font
font = ('Arial', 13)

# Create form labels and entries
tk.Label(root, text="Email:", font=font).grid(row=0, column=0, padx=5, pady=5, sticky="e")
email_entry = tk.Entry(root, font=font)
email_entry.grid(row=0, column=1, columnspan=3, padx=5, pady=5, sticky="w")

tk.Label(root, text="ID:", font=font).grid(row=1, column=0, padx=5, pady=5, sticky="e")
id_entry = tk.Entry(root, font=font)
id_entry.grid(row=1, column=1, padx=5, pady=5, sticky="w")

tk.Label(root, text="User ID:", font=font).grid(row=1, column=2, padx=5, pady=5, sticky="e")
userid_entry = tk.Entry(root, font=font)
userid_entry.grid(row=1, column=3, padx=5, pady=5, sticky="w")

tk.Label(root, text="Password:", font=font).grid(row=2, column=0, padx=5, pady=5, sticky="e")
password_entry = tk.Entry(root, show="*", font=font)
password_entry.grid(row=2, column=1, padx=5, pady=5, sticky="w")

tk.Label(root, text="Confirm Password:", font=font).grid(row=2, column=2, padx=5, pady=5, sticky="e")
confirm_password_entry = tk.Entry(root, show="*", font=font)
confirm_password_entry.grid(row=2, column=3, padx=5, pady=5, sticky="w")

tk.Label(root, text="User Firm Name:", font=font).grid(row=3, column=0, padx=5, pady=5, sticky="e")
user_firm_name_entry = tk.Entry(root, font=font)
user_firm_name_entry.grid(row=3, column=1, padx=5, pady=5, sticky="w")

tk.Label(root, text="User Form ID:", font=font).grid(row=3, column=2, padx=5, pady=5, sticky="e")
user_form_id_entry = tk.Entry(root, font=font)
user_form_id_entry.grid(row=3, column=3, padx=5, pady=5, sticky="w")

tk.Label(root, text="Name:", font=font).grid(row=4, column=0, padx=5, pady=5, sticky="e")
name_entry = tk.Entry(root, font=font)
name_entry.grid(row=4, column=1, padx=5, pady=5, sticky="w")

tk.Label(root, text="User System Name:", font=font).grid(row=4, column=2, padx=5, pady=5, sticky="e")
user_system_name_entry = tk.Entry(root, font=font)
user_system_name_entry.grid(row=4, column=3, padx=5, pady=5, sticky="w")

tk.Label(root, text="Username:", font=font).grid(row=5, column=0, padx=5, pady=5, sticky="e")
username_entry = tk.Entry(root, font=font)
username_entry.grid(row=5, column=1, padx=5, pady=5, sticky="w")

tk.Label(root, text="Role:", font=font).grid(row=5, column=2, padx=5, pady=5, sticky="e")
role_combobox = ttk.Combobox(root, values=["admin", "user", "manager"], font=font, height=5)
role_combobox.grid(row=5, column=3, padx=5, pady=5, sticky="w")

tk.Label(root, text="Theme:", font=font).grid(row=6, column=0, padx=5, pady=5, sticky="e")
theme_combobox = ttk.Combobox(root, values=["Yellow", "Red", "LightGreen"], font=font)
theme_combobox.grid(row=6, column=1, columnspan=3, padx=5, pady=5, sticky="w")
theme_combobox.current(0)

# Submit button
submit_button = tk.Button(root, text="SAVE", command=save_user, font=font)
submit_button.grid(row=7, column=0, columnspan=4, padx=5, pady=10)

root.mainloop()
